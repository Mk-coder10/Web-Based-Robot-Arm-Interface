<?php
// Connect to MySQL database
$conn = new mysqli("localhost", "root", "", "robot_arm");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Determine the action from URL (e.g., action=save)
$action = $_GET['action'] ?? '';

// Perform action based on the request
switch ($action) {

    // Save new motor values to the database
    case 'save':
        $stmt = $conn->prepare("INSERT INTO arm_positions (motor1, motor2, motor3, motor4, motor5, motor6) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("iiiiii", $_POST['motor1'], $_POST['motor2'], $_POST['motor3'], $_POST['motor4'], $_POST['motor5'], $_POST['motor6']);
        $stmt->execute();
        break;

    // Return all saved poses as table rows
    case 'list':
        $res = $conn->query("SELECT * FROM arm_positions");
        echo "<tr><th>#</th><th>Motor 1</th><th>Motor 2</th><th>Motor 3</th><th>Motor 4</th><th>Motor 5</th><th>Motor 6</th><th>Action</th></tr>";
        while($row = $res->fetch_assoc()) {
            echo "<tr>
                    <td>{$row['id']}</td>
                    <td>{$row['motor1']}</td>
                    <td>{$row['motor2']}</td>
                    <td>{$row['motor3']}</td>
                    <td>{$row['motor4']}</td>
                    <td>{$row['motor5']}</td>
                    <td>{$row['motor6']}</td>
                    <td>
                        <button onclick='runPose({$row['id']})'>Load</button>
                        <button onclick='removePose({$row['id']})'>Remove</button>
                    </td>
                  </tr>";
        }
        break;

    // Return a single pose (by ID or latest)
    case 'load':
        $id = intval($_GET['id'] ?? 0);
        $query = $id ? "SELECT * FROM arm_positions WHERE id = $id" : "SELECT * FROM arm_positions ORDER BY id DESC LIMIT 1";
        $res = $conn->query($query);
        echo json_encode($res->fetch_assoc());
        break;

    // Delete a pose by ID
    case 'delete':
        $id = intval($_GET['id']);
        $conn->query("DELETE FROM arm_positions WHERE id = $id");
        break;

    // Optional: Reset all statuses to 0
    case 'reset':
        $conn->query("UPDATE arm_positions SET status = 0");
        break;
}

// Close the connection
$conn->close();
?>
