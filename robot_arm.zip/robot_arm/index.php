<!DOCTYPE html>
<html>
<head>
    <title>Robot Arm Control Panel</title>
    <style>
        /* Basic styling for sliders and table */
        input[type=range] {
            width: 200px;
        }
        body {
            font-family: Arial, sans-serif;
        }
        table, th, td {
            border: 1px solid #000;
            border-collapse: collapse;
            padding: 6px 10px;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h2>Robot Arm Control Panel</h2>

    <!-- Create 6 motor sliders using a loop -->
    <?php
        for ($i = 1; $i <= 6; $i++) {
            echo "Motor $i: 
                <input type='range' min='0' max='180' value='90' id='motor$i' oninput='updateValue($i)' />
                <span id='val$i'>90</span><br>";
        }
    ?>

    <br>
    <!-- Control buttons -->
    <button onclick="reset()">Reset</button>
    <button onclick="savePose()">Save Pose</button>
    <button onclick="runPose()">Run Last Pose</button>

    <h3>Saved Arm Positions</h3>
    <!-- Table to show saved poses -->
    <table id="poseTable"></table>

    <script>
        // Update the number next to each slider
        function updateValue(i) {
            document.getElementById("val" + i).innerText = document.getElementById("motor" + i).value;
        }

        // Reset all sliders to 90
        function reset() {
            for (let i = 1; i <= 6; i++) {
                document.getElementById("motor" + i).value = 90;
                updateValue(i);
            }
        }

        // Save current motor values to the database
        function savePose() {
            const data = new FormData();
            for (let i = 1; i <= 6; i++) {
                data.append("motor" + i, document.getElementById("motor" + i).value);
            }

            fetch("api.php?action=save", {
                method: "POST",
                body: data
            }).then(() => loadTable());
        }

        // Load pose data into sliders
        function runPose(id = null) {
            fetch("api.php?action=load&id=" + (id || ""))
                .then(res => res.json())
                .then(data => {
                    if (data && data.id) {
                        for (let i = 1; i <= 6; i++) {
                            document.getElementById("motor" + i).value = data["motor" + i];
                            updateValue(i);
                        }
                    }
                });
        }

        // Load and display all saved poses in the table
        function loadTable() {
            fetch("api.php?action=list")
                .then(res => res.text())
                .then(html => {
                    document.getElementById("poseTable").innerHTML = html;
                });
        }

        // Delete a pose from the database by ID
        function removePose(id) {
            fetch("api.php?action=delete&id=" + id)
                .then(() => loadTable());
        }

        // Load poses when the page starts
        window.onload = loadTable;
    </script>
</body>
</html>
